require "/cgi/tmi/saison.pl";

$vold=$main_saison[$main_nr-1];
$vold=~s/Saison 20//;
$vold=~s/'//;

$old=$main_saison[$main_nr];
$old=~s/Saison 20//;
$old=~s/'//;

$new=$main_saison[$main_nr+1];
$new=~s/Saison 20//;
$new=~s/'//;

if ( $old eq "" || $new eq "" || $old eq ".." ) { exit ; }
print "Content-type:text/html\n\n";
print "\n\nSaisonumstellung von $old -> $new [ <- richtige Saisonk�rzel ? nur dann Fortfahren ]";
&break;
print "Sichere Saisondaten in /tmi/archiv/$old/\n";
print "Setze Softlink /tmi/archiv/$new/ -> /tmi\n";
&break;

`rm /tmi/archiv/$old`;
`mkdir /tmi/archiv/$old/`;
`mkdir /tmi/archiv/$old/pokal/`;
`ln -s /tmi /tmi/archiv/$new`;

`cp /tmi/DAT*.TXT /tmi/archiv/$old/`;
`mv /tmi/formular*.t* /tmi/archiv/$old/`;
`cp /tmi/spieltag.txt /tmi/archiv/$old/`;
`cp /tmi/history.txt /tmi/archiv/$old/`;
`cp /tmi/heer.txt /tmi/archiv/$old/`;
`cp /tmi/pass.txt /tmi/archiv/$old/`;
`cp /tmi/final.txt /tmi/archiv/$old/`;
`cp /tmi/archiv/022/datum.txt /tmi/archiv/$old/`;
`cp /tmi/pokal/*.* /tmi/archiv/$old/pokal/`;
`cp /tmi/nm/*-[1-9].txt /tmi/archiv/$old/`;
print "... beendet.";
&break;


print "L�sche tempor�re Save Dateien + Neuaufsetzung Freundschaftspiele und Job B�rse Wechselliste\n";
&break;
`rm /tmi/boerse_[0-9].txt`;
`rm /tmi/error_tips_*.txt`;
`rm /tmi/history_s*_*.txt`;
`rm /tmi/zat*.txt`;
`rm /tmi/exdat/*.*`;
`rm /tmi/nm/*-[1-9].txt`;
`mv /tmi/friendly/friendly.txt /tmi/friendly/friendly$old.txt`;
`cp /tmi/friendly/nummer_init.txt /tmi/friendly/nummer.txt`;
`mv /tmi/wechsel.txt /tmi/wechsel$old.txt`;
`rm /tmi/lm-tips*`;
print "... beendet.";
&break;

print "Zippe Tipdaten Dateien aus /tmi/tipos nach /tmi/tipos$old.zip \n";
&break;
`zip /tmi/tipos$old.zip /tmi/tipos/*.TXT`;
print "... beendet.";
&break;

print "L�sche Dateien aus /tmi/tipos und Tipfiles aus /tmi/tips/*/ [ dauert ne Weile :-) ]  \n";
&break;
`rm /tmi/tipos/*.*`;
`rm /tmi/tips/1/*.*`;print "Sp.1 gel�scht ...\n";
`rm /tmi/tips/5/*.*`;print "Sp.5 gel�scht ...\n";
`rm /tmi/tips/9/*.*`;print "Sp.9 gel�scht ...\n";
`rm /tmi/tips/13/*.*`;print "Sp.13 gel�scht ...\n";
`rm /tmi/tips/17/*.*`;print "Sp.17 gel�scht ...\n";
`rm /tmi/tips/21/*.*`;print "Sp.21 gel�scht ...\n";
`rm /tmi/tips/25/*.*`;print "Sp.25 gel�scht ...\n";
`rm /tmi/tips/29/*.*`;print "Sp.29 gel�scht ...\n";
`rm /tmi/tips/33/*.*`;print "Sp.33 gel�scht ...\n";
`rm -r /tmi/pokal/tips/`;print "L�sche Pokaltips ...\n";
`rm /tmi/pokal/pokal_qu[1-5].txt`;print "L�sche Pokalquoten ...\n";


`mkdir /tmi/pokal/tips/`;

print "... beendet.";
&break;


print "Verschiebe Aktionen der 'Big Mama' /tmi/db/spiele.txt\n";
&break;

`mv /tmi/db/spiele_old.txt /tmi/db/spiele_old_$vold.txt`;
`mv /tmi/db/spiele.txt /tmi/db/spiele_old.txt`;
print "... beendet.";
&break;

print "Schreibe Vereinshistorien\n";
&break;
require "ns_sai_history.pl";
&break;

print "Erstelle neue history.txt und lege Sie ab in /tmi/swechsel\n";
&break;
require "ns_sai_wechsel.pl";
&break;

print "Setze die /tmi/DAT*.TXT Dateien auf Saisonbeginn \n";
&break;
require "sai_neudat.pl";
&break;

print "Setze Saisonvariablen auf Saisonstart ( Spielrunde = 1 , Tipabgabe ab Sp.1 , Saisonnr ++ , Pokalrunde =1 etc. ) \n";
&break;
open (D1,">/home/tipmaster/tmi/tip_datum.txt");print D1 "1";close(D1);
open (D1,">/home/tipmaster/tmi/datum.txt");print D1 "1\n1\n";close(D1);
open (D1,">/home/tipmaster/tmi/pokal/pokal_datum.txt");print D1 "1";close(D1);

require "/cgi/tmi/saison.pl";
$sai_new=$main_nr+1;
open (D1,">/home/tipmaster/tmi/main_nr.txt");print D1 "$sai_new\n";close(D1);
print "... beendet.";
&break;

`cp /tmi/swechsel/history.txt /tmi/history.txt`;


`perl /pl/tmi/heer.pl &`;                   # berechnet Tabellenplazierung f�r Job-B�rse etc.
`perl /tmi/swechsel/erfolge_readout.pl &`;  # bisherige deutsche meister werden ausgelesen
`perl /tmi/swechsel/cup_winner_readout.pl &`;    # bisherige dfb pokalsieger werden ausgelesen
`nice -15 perl /tmi/db/stats_ns.pl &`;

exit ;
sub break{
#print "\n[ Fortfahren ? Weiter mit Enter ]\n\n";$a=<stdin>;
print "<br><br>";


}
